# AVESON CORE SERVER

AVESON CORE SERVER is the independent backend service stored in the same GitHub repository as the AVESON CENTRAL Android application for now.

The backend is a separate program. It is **not** an Android app and is not bundled into the Android APK.

## Initial foundation

- NestJS / Node.js REST API
- PostgreSQL database
- Docker Compose for local PostgreSQL development
- Health and database-readiness endpoints
- Initial artist, release, asset-reference, and review-history schema

## Local preparation

1. Install Node.js 22 or later and Docker Desktop / Docker Engine.
2. Copy `.env.example` to `.env`.
3. Set a strong local `DATABASE_PASSWORD` in `.env`.
4. Start PostgreSQL from this directory:

   ```bash
   docker compose up -d postgres
   ```

5. Install backend dependencies and start the API:

   ```bash
   npm install
   npm run start:dev
   ```

6. Check:
   - `GET http://localhost:3000/health`
   - `GET http://localhost:3000/health/ready`

## Important safety notes

- Do not commit `.env`, real passwords, API keys, or private certificates.
- PostgreSQL is bound to `127.0.0.1` in the local Compose file; do not expose its port publicly.
- The current API is only a foundation. It does not yet implement staff login, permissions, artist/release CRUD, file upload, distribution workflows, or production deployment.
- The SQL file is an initial schema, not a production migration system.
- Production must use TLS, secrets management, firewall rules, tested backups, monitoring, and a controlled database migration process.
- Cloud/private server replication and automatic failover are not implemented yet.


## AVESON CENTRAL APK Update API (initial server-side implementation)

The read-only update API is available at:
- `GET /updates/aveson-central/latest`
- `GET /updates/aveson-central/apk`

See `updates/README.md` and `.env.example` for release publishing steps.
The API computes the APK SHA-256 from the actual APK file and returns it in the
manifest. It does not provide an admin upload/publish endpoint; deployment staff
place a signed release APK on the server and update the environment metadata.

This is the server side only. The Android client-side checker/downloader/installer
is a separate next step and is not included in this ZIP.

# AVESON CENTRAL APK publishing

This folder is the local staging location for the release APK.

1. Build a signed release APK for the existing AVESON CENTRAL application.
2. Keep the same Android `applicationId` and signing certificate as the installed app.
3. Increase `versionCode` for every release.
4. Copy the signed APK to `server/updates/aveson-central.apk` (or configure `UPDATE_APK_PATH`).
5. Set the update metadata in the server `.env`.
6. Deploy the backend over HTTPS.

The API is read-only:
- `GET /updates/aveson-central/latest` returns version metadata and the APK SHA-256.
- `GET /updates/aveson-central/apk` streams the APK.

Do not publish debug APKs or an APK signed with a different key. The Android client must
compare version codes, download to app-private storage, verify SHA-256, and then launch
Android's package installer. Standard Android devices require the user to confirm install.

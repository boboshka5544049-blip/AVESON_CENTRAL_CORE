import {
  Controller,
  Get,
  Header,
  Res,
  StreamableFile,
} from '@nestjs/common';
import type { Response } from 'express';
import { UpdatesService } from './updates.service';

@Controller('updates/aveson-central')
export class UpdatesController {
  constructor(private readonly updates: UpdatesService) {}

  // Public read-only endpoint used by the installed Android app.
  @Get('latest')
  @Header('Cache-Control', 'no-store')
  async latest() {
    return this.updates.getLatestManifest();
  }

  // Streams the APK; the Android app must verify the SHA-256 from /latest.
  @Get('apk')
  @Header('Content-Type', 'application/vnd.android.package-archive')
  @Header('Cache-Control', 'no-store')
  async apk(@Res({ passthrough: true }) response: Response) {
    const file = await this.updates.getApkStream();
    response.setHeader(
      'Content-Disposition',
      `attachment; filename="${file.fileName.replace(/["\\\\]/g, '')}"`,
    );
    response.setHeader('Content-Length', String(file.fileSizeBytes));
    return new StreamableFile(file.stream);
  }
}

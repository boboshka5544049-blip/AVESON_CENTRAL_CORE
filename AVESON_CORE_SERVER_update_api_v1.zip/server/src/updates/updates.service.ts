import {
  Injectable,
  NotFoundException,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { access, stat } from 'node:fs/promises';
import { basename, resolve } from 'node:path';

export interface UpdateManifest {
  appId: string;
  versionCode: number;
  versionName: string;
  minimumSupportedVersionCode: number;
  apkUrl: string;
  sha256: string;
  fileSizeBytes: number;
  releaseNotes: string[];
  publishedAt: string;
}

@Injectable()
export class UpdatesService {
  constructor(private readonly config: ConfigService) {}

  async getLatestManifest(): Promise<UpdateManifest> {
    const apkPath = this.getApkPath();
    await this.ensureApkExists(apkPath);

    const fileInfo = await stat(apkPath);
    const sha256 = await this.calculateSha256(apkPath);
    const publicBaseUrl = (this.config.get<string>('UPDATE_PUBLIC_BASE_URL') || '')
      .replace(/\/+$/, '');

    if (!publicBaseUrl) {
      throw new ServiceUnavailableException(
        'UPDATE_PUBLIC_BASE_URL is not configured',
      );
    }

    const versionCode = Number(this.config.get<string>('UPDATE_VERSION_CODE'));
    const minimumSupportedVersionCode = Number(
      this.config.get<string>('UPDATE_MIN_SUPPORTED_VERSION_CODE') || '1',
    );
    if (!Number.isSafeInteger(versionCode) || versionCode < 1) {
      throw new ServiceUnavailableException('UPDATE_VERSION_CODE is invalid');
    }
    if (
      !Number.isSafeInteger(minimumSupportedVersionCode) ||
      minimumSupportedVersionCode < 1 ||
      minimumSupportedVersionCode > versionCode
    ) {
      throw new ServiceUnavailableException(
        'UPDATE_MIN_SUPPORTED_VERSION_CODE is invalid',
      );
    }

    const versionName = this.config.get<string>('UPDATE_VERSION_NAME') || '';
    const publishedAt = this.config.get<string>('UPDATE_PUBLISHED_AT') || '';
    if (!versionName || !publishedAt || Number.isNaN(Date.parse(publishedAt))) {
      throw new ServiceUnavailableException(
        'UPDATE_VERSION_NAME or UPDATE_PUBLISHED_AT is missing/invalid',
      );
    }

    const releaseNotes = (this.config.get<string>('UPDATE_RELEASE_NOTES') || '')
      .split('|')
      .map((note) => note.trim())
      .filter(Boolean);

    return {
      appId: this.config.get<string>('UPDATE_APPLICATION_ID') ||
        'com.aveson.central.core',
      versionCode,
      versionName,
      minimumSupportedVersionCode,
      apkUrl: `${publicBaseUrl}/updates/aveson-central/apk`,
      sha256,
      fileSizeBytes: fileInfo.size,
      releaseNotes,
      publishedAt,
    };
  }

  async getApkStream(): Promise<{
    stream: ReturnType<typeof createReadStream>;
    fileName: string;
    fileSizeBytes: number;
  }> {
    const apkPath = this.getApkPath();
    await this.ensureApkExists(apkPath);
    const fileInfo = await stat(apkPath);

    return {
      stream: createReadStream(apkPath),
      fileName: basename(apkPath),
      fileSizeBytes: fileInfo.size,
    };
  }

  private getApkPath(): string {
    const configuredPath = this.config.get<string>('UPDATE_APK_PATH') ||
      './updates/aveson-central.apk';
    return resolve(process.cwd(), configuredPath);
  }

  private async ensureApkExists(apkPath: string): Promise<void> {
    try {
      await access(apkPath);
    } catch {
      throw new NotFoundException(
        'No AVESON CENTRAL update APK has been published on this server',
      );
    }
  }

  private async calculateSha256(filePath: string): Promise<string> {
    const hash = createHash('sha256');
    const stream = createReadStream(filePath);

    await new Promise<void>((resolvePromise, reject) => {
      stream.on('data', (chunk: Buffer) => hash.update(chunk));
      stream.on('error', reject);
      stream.on('end', resolvePromise);
    });

    return hash.digest('hex');
  }
}

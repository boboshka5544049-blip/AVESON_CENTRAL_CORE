import { Global, Module, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Pool } from 'pg';
import { DATABASE_POOL } from './database.constants';

@Global()
@Module({
  providers: [
    {
      provide: DATABASE_POOL,
      inject: [ConfigService],
      useFactory: (config: ConfigService): Pool =>
        new Pool({
          host: config.get<string>('DATABASE_HOST', '127.0.0.1'),
          port: config.get<number>('DATABASE_PORT', 5432),
          database: config.get<string>('DATABASE_NAME', 'aveson_core'),
          user: config.get<string>('DATABASE_USER', 'aveson_app'),
          password: config.get<string>('DATABASE_PASSWORD', ''),
          ssl: config.get<string>('DATABASE_SSL') === 'true'
            ? { rejectUnauthorized: true }
            : undefined,
          max: 10,
          connectionTimeoutMillis: 5000,
        }),
    },
  ],
  exports: [DATABASE_POOL],
})
export class DatabaseModule implements OnModuleDestroy {
  constructor(private readonly pool: Pool) {}

  async onModuleDestroy(): Promise<void> {
    await this.pool.end();
  }
}

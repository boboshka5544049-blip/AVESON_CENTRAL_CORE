import { Controller, Get, Inject, ServiceUnavailableException } from '@nestjs/common';
import { Pool } from 'pg';
import { DATABASE_POOL } from '../database/database.constants';

@Controller('health')
export class HealthController {
  constructor(@Inject(DATABASE_POOL) private readonly pool: Pool) {}

  @Get()
  getHealth(): { service: string; status: string } {
    return {
      service: 'AVESON CORE SERVER',
      status: 'running',
    };
  }

  @Get('ready')
  async getReadiness(): Promise<{ service: string; status: string; database: string }> {
    try {
      await this.pool.query('SELECT 1');
      return {
        service: 'AVESON CORE SERVER',
        status: 'ready',
        database: 'connected',
      };
    } catch {
      throw new ServiceUnavailableException({
        service: 'AVESON CORE SERVER',
        status: 'not_ready',
        database: 'unavailable',
      });
    }
  }
}

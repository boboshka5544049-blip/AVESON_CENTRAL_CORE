# AVESON CORE SERVER — initial architecture decision

## Repository decision
For now, Android and backend source code remain in one GitHub repository, in separate directories. The backend can be split into its own repository later.

## Runtime separation
- `app/`: AVESON CENTRAL Android application.
- `server/`: independent NestJS backend service.
- `database/`: PostgreSQL schema and, later, versioned migrations.
- `infrastructure/cloud-server/`: future cloud VPS deployment configuration.
- `infrastructure/private-server/`: future company-owned physical server configuration.

## Deployment sequence
1. Prepare and test the backend locally.
2. Deploy the first production instance to a rented cloud VPS.
3. Purchase and prepare the company's private physical server later.
4. Configure database replication, file replication, backup, monitoring, and tested failover before relying on either server as a standby.
5. Keep one authoritative writable database role at a time unless a deliberately designed multi-writer system is introduced.

## Not implemented yet
- Production authentication and role-based authorization.
- Artist and release API endpoints.
- Audio/cover object storage and upload/download authorization.
- Distribution workflow.
- Cloud/private replication and automatic failover.
- Production deployment and disaster-recovery testing.
